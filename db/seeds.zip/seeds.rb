# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)


#personnel = Personnel.create(id: '1234567890', email: 'root@cu.com', role: 'I', password: 'dbdbdbdb')
#student = Student.create(id: '1234567890', email: 'aaa@bbb.ccc', curriculum_id: '1234567890')

#Student_create
Student.create(id: "731079821", first_name: 'พัชริดา', last_name: 'พัดพาดี', picture: 'pic_url_here', ssn: '10000000000', birth_date:'12-19-1994', gender: 'Female', enroll_year: '2014', status: 'normal', email: 'calojy@hotmail.com', curriculum_id: '1')
Student.create(id: "731110521", first_name: 'โสภิตา', last_name: 'ปัญญาคำ', picture: 'pic_url_here', ssn: '10000000001', birth_date:'8-26-1996', gender: 'Female', enroll_year: '2014', status: 'normal', email: 'khamint@hotmail.com', curriculum_id: '1')
Student.create(id: "730300221", first_name: 'นันทนัช', last_name: 'ยืนยงเดชาวัฒน์', picture: 'pic_url_here', ssn: '10000000002', birth_date:'7-10-1995', gender: 'Female', enroll_year: '2014', status: 'normal', email: 'salapao_oo@hotmail.com', curriculum_id: '1')
Student.create(id: "730119021", first_name: 'ชวิศา', last_name: 'ธรรมจรัส', picture: 'pic_url_here', ssn: '10000000003', birth_date:'12-12-1995', gender: 'Female', enroll_year: '2014', status: 'normal', email: 'jijy.chavisa@gmail.com', curriculum_id: '1')
Student.create(id: "731074621", first_name: 'ปาลิดา', last_name: 'ทองทิวา', picture: 'pic_url_here', ssn: '10000000004', birth_date:'11-15-1995', gender: 'Female', enroll_year: '2014', status: 'normal', email: 'palida.th@hotmail.com', curriculum_id: '1')
Student.create(id: "731075221", first_name: 'ปิยะฉัตร', last_name: 'มงคลพัฒนกุล', picture: 'pic_url_here', ssn: '10000000005', birth_date:'3-19-1996', gender: 'Female', enroll_year: '2014', status: 'normal', email: 'quinnside-9@hotmail.com', curriculum_id: '1')
Student.create(id: "730321421", first_name: 'ปณิดา', last_name: 'วิริยะชัยพร', picture: 'pic_url_here', ssn: '10000000006', birth_date:'5-21-1996', gender: 'Female', enroll_year: '2014', status: 'normal', email: 'neufii.s@gmail.com', curriculum_id: '1')
Student.create(id: "730402621", first_name: 'พิมพ์ชนก', last_name: 'พงศ์สุพรรณกิจ', picture: 'pic_url_here', ssn: '10000000007', birth_date:'11-10-1995', gender: 'Female', enroll_year: '2014', status: 'normal', email: 'beautifut_@hotmail.com', curriculum_id: '1')
Student.create(id: "730635521", first_name: 'สิรินทรา', last_name: 'จันทะราช', picture: 'pic_url_here', ssn: '10000000008', birth_date:'6-19-1996', gender: 'Female', enroll_year: '2014', status: 'normal', email: 'sirinthra.cc@gmail.com', curriculum_id: '1')
Student.create(id: "731069521", first_name: 'บุญลักษณ์', last_name: 'สันติธำรงวิทย์', picture: 'pic_url_here', ssn: '10000000009', birth_date:'12-5-1995', gender: 'Female', enroll_year: '2014', status: 'normal', email: 'beeviolet@hotmail.com', curriculum_id: '1')
Student.create(id: "731078121", first_name: 'พรรษพิรุณ', last_name: 'ถิรจิตโต', picture: 'pic_url_here', ssn: '10000000010', birth_date:'9-26-1995', gender: 'Female', enroll_year: '2014', status: 'normal', email: 'faai.ppt@gmail.com', curriculum_id: '1')
Student.create(id: "731101921", first_name: 'ศศิชา', last_name: 'พูนพล', picture: 'pic_url_here', ssn: '10000000011', birth_date:'8-17-1996', gender: 'Female', enroll_year: '2014', status: 'normal', email: 'puifai-yoon_eun_hae@hotmail.com', curriculum_id: '1')
Student.create(id: "730677921", first_name: 'อรพรรณ', last_name: 'โพธิ์งามวงศ์', picture: 'pic_url_here', ssn: '10000000012', birth_date:'4-13-1995', gender: 'Female', enroll_year: '2014', status: 'normal', email: 'orraphan.op@gmail.com', curriculum_id: '1')
Student.create(id: "731055721", first_name: 'ธาริณี', last_name: 'มั่นความดี', picture: 'pic_url_here', ssn: '10000000013', birth_date:'9-30-1995', gender: 'Female', enroll_year: '2014', status: 'normal', email: 'tharinee_fang@hotmail.com', curriculum_id: '1')
Student.create(id: "730295821", first_name: 'นวินดา', last_name: 'บุญประโลม', picture: 'pic_url_here', ssn: '10000000014', birth_date:'12-17-1995', gender: 'Female', enroll_year: '2014', status: 'normal', email: 'fern.elf_129@hotmail.com', curriculum_id: '1')
Student.create(id: "731092921", first_name: 'มินตรา', last_name: 'นานคงแนบ', picture: 'pic_url_here', ssn: '10000000015', birth_date:'10-29-1995', gender: 'Female', enroll_year: '2014', status: 'normal', email: 'mind_lover_soul@hotmail.com', curriculum_id: '1')
Student.create(id: "731007621", first_name: 'กานต์กวี', last_name: 'ชนะสิทธิ์', picture: 'pic_url_here', ssn: '10000000016', birth_date:'8-19-1995', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'shionz_zeroz@hotmail.com', curriculum_id: '1')
Student.create(id: "731004721", first_name: 'กวิน', last_name: 'เหลี่ยววงค์ภูธร', picture: 'pic_url_here', ssn: '10000000017', birth_date:'9-7-1995', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'liaokangtai@gmail.com', curriculum_id: '2')
Student.create(id: "730688821", first_name: 'อัชระพนธ์', last_name: 'ศิลมัฐ', picture: 'pic_url_here', ssn: '10000000018', birth_date:'2-24-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'great_ascharapon@hotmail.com', curriculum_id: '2')
Student.create(id: "731009921", first_name: 'เกรียงศักดิ์', last_name: 'หทัยเกษมสุข', picture: 'pic_url_here', ssn: '10000000019', birth_date:'1-4-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'N.P.K.channel@gmail.com', curriculum_id: '2')
Student.create(id: "731111121", first_name: 'อธิป', last_name: 'อินทรภิรมย์', picture: 'pic_url_here', ssn: '10000000020', birth_date:'2-9-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'kame_1996@hotmail.com', curriculum_id: '2')
Student.create(id: "731035121", first_name: 'ณัฐภัทร', last_name: 'กิระวิทยา', picture: 'pic_url_here', ssn: '10000000021', birth_date:'3-13-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'nut_stick@hotmail.com', curriculum_id: '2')
Student.create(id: "730282621", first_name: 'นนทิวัฒน์', last_name: 'วิสุทธิไกรสีห์', picture: 'pic_url_here', ssn: '10000000022', birth_date:'5-3-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'keenesis@gmail.com', curriculum_id: '2')
Student.create(id: "731040221", first_name: 'ธนกฤต', last_name: 'โกวิทวณิช', picture: 'pic_url_here', ssn: '10000000023', birth_date:'7-31-1995', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'thanakit_1995@hotmail.com', curriculum_id: '2')
Student.create(id: "730241921", first_name: 'ธนวัฒน์', last_name: 'สอสะอาด', picture: 'pic_url_here', ssn: '10000000024', birth_date:'11-19-1995', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'lordspinner@hotmail.com', curriculum_id: '2')
Student.create(id: "730196321", first_name: 'ดนุภัทร', last_name: 'คำนวนสินธุ์', picture: 'pic_url_here', ssn: '10000000025', birth_date:'4-30-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'jrkns1996@gmail.com', curriculum_id: '2')
Student.create(id: "730398821", first_name: 'พิชญุตม์', last_name: 'จิตรศิลป์ฉายากุล', picture: 'pic_url_here', ssn: '10000000026', birth_date:'10-20-1995', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'pitchayut.jr@hotmail.com', curriculum_id: '2')
Student.create(id: "730192821", first_name: 'ณัฐสิทธิ์', last_name: 'มหากุศลศิริกุล', picture: 'pic_url_here', ssn: '10000000027', birth_date:'10-27-1995', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'nuttasit.mah@gmail.com', curriculum_id: '2')
Student.create(id: "730251121", first_name: 'ธเนศ', last_name: 'สิริจรรยาพงศ์', picture: 'pic_url_here', ssn: '10000000028', birth_date:'9-29-1995', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'ai_thanet@hotmail.com', curriculum_id: '2')
Student.create(id: "730367321", first_name: 'พชร', last_name: 'โชคดุรงค์', picture: 'pic_url_here', ssn: '10000000029', birth_date:'10-31-1995', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'j_pcr@hotmail.com', curriculum_id: '2')
Student.create(id: "730328921", first_name: 'ปริญญ์', last_name: 'จิตเสรีธรรม', picture: 'pic_url_here', ssn: '10000000030', birth_date:'4-6-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'prin_jit@hotmail.com', curriculum_id: '2')
Student.create(id: "730281021", first_name: 'นนทัช', last_name: 'บุณยมานนท์', picture: 'pic_url_here', ssn: '10000000031', birth_date:'10-2-1995', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'jeff036690@gmail.com', curriculum_id: '2')
Student.create(id: "730174521", first_name: 'ณัฐพล', last_name: 'รักษ์รัชตกุล', picture: 'pic_url_here', ssn: '10000000032', birth_date:'3-8-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'darkjame_2539@hotmail.com', curriculum_id: '2')
Student.create(id: "730411221", first_name: 'พีรณัฐ', last_name: 'จริยรักษ์วรกุล', picture: 'pic_url_here', ssn: '10000000033', birth_date:'6-20-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'james9007001@hotmail.com', curriculum_id: '2')
Student.create(id: "731018521", first_name: 'จิรันตน์', last_name: 'บวรกิติวงศ์', picture: 'pic_url_here', ssn: '10000000034', birth_date:'5-5-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'jamebond1996@hotmail.com', curriculum_id: '3')
Student.create(id: "731087821", first_name: 'ภาคภูมิ', last_name: 'ทวีสิทธิชาติ', picture: 'pic_url_here', ssn: '10000000035', birth_date:'11-26-1993', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'pakpoom.tha@outlook.com', curriculum_id: '3')
Student.create(id: "731091221", first_name: 'ภุมรินทร์', last_name: 'พลอยพิศุทธิ์', picture: 'pic_url_here', ssn: '10000000036', birth_date:'8-10-1995', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'joey.161@hotmail.com', curriculum_id: '3')
Student.create(id: "730243121", first_name: 'ธนัช', last_name: 'จตุภัทรฉัตร', picture: 'pic_url_here', ssn: '10000000037', birth_date:'1-23-1995', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'thanat.jat@gmail.com', curriculum_id: '3')
Student.create(id: "731022021", first_name: 'ชัชชนก', last_name: 'อาศุเวทย์', picture: 'pic_url_here', ssn: '10000000038', birth_date:'1-9-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'chatshanok@hotmail.com', curriculum_id: '3')
Student.create(id: "730684221", first_name: 'อวยชัย', last_name: 'บูรณมานิต', picture: 'pic_url_here', ssn: '10000000039', birth_date:'3-14-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'aouycd44@gmail.com', curriculum_id: '3')
Student.create(id: "731045421", first_name: 'ธนภัทร', last_name: 'อารีจิตสกุล', picture: 'pic_url_here', ssn: '10000000040', birth_date:'8-12-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'thanaphata79@gmail.com', curriculum_id: '3')
Student.create(id: "731059221", first_name: 'ธีรภัทร', last_name: 'สุจิตโต', picture: 'pic_url_here', ssn: '10000000041', birth_date:'4-16-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'teerapart.s@gmail.com', curriculum_id: '3')
Student.create(id: "730365021", first_name: 'พงศยา', last_name: 'สมบูรณ์พงศ์', picture: 'pic_url_here', ssn: '10000000042', birth_date:'12-9-1995', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'pongsaya55_@hotmail.com', curriculum_id: '3')
Student.create(id: "731015621", first_name: 'จิรพัฒน์', last_name: 'อติวัฒนชัย', picture: 'pic_url_here', ssn: '10000000043', birth_date:'4-26-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'jirapatdew@gmail.com', curriculum_id: '3')
Student.create(id: "731014021", first_name: 'จาตุรนต์', last_name: 'ศุภศรี', picture: 'pic_url_here', ssn: '10000000044', birth_date:'3-17-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'domejaturonsupasri@gmail.com', curriculum_id: '3')
Student.create(id: "731032221", first_name: 'ณพล', last_name: 'อยรังสฤษฎ์กูล', picture: 'pic_url_here', ssn: '10000000045', birth_date:'6-3-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'naphol2000@hotmail.com', curriculum_id: '3')
Student.create(id: "731086121", first_name: 'ภควัต', last_name: 'ลีลาคหกิจ', picture: 'pic_url_here', ssn: '10000000046', birth_date:'5-2-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'homesnet1234@hotmail.com', curriculum_id: '3')
Student.create(id: "731095821", first_name: 'วสุวัชร', last_name: 'สถิตธรรมจิตร', picture: 'pic_url_here', ssn: '10000000047', birth_date:'11-17-1990', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'wasuwach@hotmail.com', curriculum_id: '3')
Student.create(id: "730625221", first_name: 'สิทธิชัย', last_name: 'แซ่เจี่ย', picture: 'pic_url_here', ssn: '10000000048', birth_date:'2-8-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'tueytobi@gmail.com', curriculum_id: '3')
Student.create(id: "731068921", first_name: 'บรรณ', last_name: 'อุทัยธิรัตน์', picture: 'pic_url_here', ssn: '10000000049', birth_date:'4-12-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'taobunoi@gmail.com', curriculum_id: '3')
Student.create(id: "730410621", first_name: 'พีรกิต', last_name: 'อุ่มบางตลาด', picture: 'pic_url_here', ssn: '10000000050', birth_date:'2-9-1995', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'eye-of-infinity@hotmail.com', curriculum_id: '3')
Student.create(id: "730540521", first_name: 'วศิน', last_name: 'ปณิธานศิริกุล', picture: 'pic_url_here', ssn: '10000000051', birth_date:'8-22-1995', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'wasin.p1995@gmail.com', curriculum_id: '4')
Student.create(id: "731020721", first_name: 'เจตพัฒน์', last_name: 'ทิตอร่าม', picture: 'pic_url_here', ssn: '10000000052', birth_date:'10-11-1994', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'hennet2@hotmail.com', curriculum_id: '4')
Student.create(id: "731088421", first_name: 'ภานุพงศ์', last_name: 'ทองธวัช', picture: 'pic_url_here', ssn: '10000000053', birth_date:'3-22-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'panupong.not@hotmail.com', curriculum_id: '4')
Student.create(id: "731109021", first_name: 'สุธรรม', last_name: 'ธิติอนันต์ปกรณ์', picture: 'pic_url_here', ssn: '10000000054', birth_date:'10-22-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'north_2_1_44@hotmail.com', curriculum_id: '4')
Student.create(id: "730175121", first_name: 'ณัฐพล', last_name: 'เราพิพัฒน์พงษ์', picture: 'pic_url_here', ssn: '10000000055', birth_date:'4-4-1995', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'thundernut_inwzainwza@hotmail.com', curriculum_id: '4')
Student.create(id: "731036821", first_name: 'ณัฐภัทร', last_name: 'บุญประคอง', picture: 'pic_url_here', ssn: '10000000056', birth_date:'4-29-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'nattapatboon@gmail.com', curriculum_id: '4')
Student.create(id: "731048321", first_name: 'ธนิน', last_name: 'ตันเฉี่ยง', picture: 'pic_url_here', ssn: '10000000057', birth_date:'8-27-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'nin4511@hotmail.com', curriculum_id: '4')
Student.create(id: "731047721", first_name: 'ธนะ', last_name: 'กิจกุลอนันตเอก', picture: 'pic_url_here', ssn: '10000000058', birth_date:'11-4-1994', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'inmemory_8566@hotmail.com', curriculum_id: '4')
Student.create(id: "731077521", first_name: 'พงษ์พีรเดช', last_name: 'ชัยธรรม', picture: 'pic_url_here', ssn: '10000000059', birth_date:'5-2-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'netklause@gmail.com', curriculum_id: '4')
Student.create(id: "731065021", first_name: 'นัทธ์', last_name: 'ศรีเรือนทอง', picture: 'pic_url_here', ssn: '10000000060', birth_date:'8-8-1995', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'srtnat@hotmail.com', curriculum_id: '4')
Student.create(id: "731112821", first_name: 'อนุรุธ', last_name: 'เลิศปิยะ', picture: 'pic_url_here', ssn: '10000000061', birth_date:'9-11-1995', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'bobby_nh@me.com', curriculum_id: '4')
Student.create(id: "730529721", first_name: 'วริทธิ์ธร', last_name: 'สุทธิิโสภาอาภรณ์', picture: 'pic_url_here', ssn: '10000000062', birth_date:'5-4-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'bossclues@gmail.com', curriculum_id: '4')
Student.create(id: "730447921", first_name: 'ภาณุวิชญ์', last_name: 'วงศ์อนันต์กิจ', picture: 'pic_url_here', ssn: '10000000063', birth_date:'8-4-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'bas_kung02@hotmail.com', curriculum_id: '4')
Student.create(id: "731070021", first_name: 'บุญศรัณย์', last_name: 'ขจรกลิ่นมาลา', picture: 'pic_url_here', ssn: '10000000064', birth_date:'9-28-1995', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'boonsaran@hotmail.com', curriculum_id: '4')
Student.create(id: "730593821", first_name: 'ศุภกฤต', last_name: 'เปาลิวัฒน์', picture: 'pic_url_here', ssn: '10000000065', birth_date:'5-16-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'supakritboom@hotmail.com', curriculum_id: '4')
Student.create(id: "731119221", first_name: 'เอกธนัช', last_name: 'อัฑฒพงษ์', picture: 'pic_url_here', ssn: '10000000066', birth_date:'5-20-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'bestmaxger@hotmail.com', curriculum_id: '4')
Student.create(id: "730022821", first_name: 'กฤษดา', last_name: 'พรรัตน์ธนพงศ์', picture: 'pic_url_here', ssn: '10000000067', birth_date:'8-16-1995', gender: 'Female', enroll_year: 1986, status: 'jailed', email: 'kissada147@gmail.com', curriculum_id: '4')
Student.create(id: "730303121", first_name: 'นิธิชัย', last_name: 'ติยอมรวงศ์', picture: 'pic_url_here', ssn: '10000000068', birth_date:'9-6-1995', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'nitichai2@gmail.com', curriculum_id: '4')
Student.create(id: "731076921", first_name: 'พงศธร', last_name: 'โชติพันธุ์วิทยากุล', picture: 'pic_url_here', ssn: '10000000069', birth_date:'2-8-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'happyworld@windowslive.com', curriculum_id: '4')
Student.create(id: "731002421", first_name: 'กรวีร์', last_name: 'การุณรัตนกุล', picture: 'pic_url_here', ssn: '10000000070', birth_date:'2-21-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'korrawe@hotmail.com', curriculum_id: '4')
Student.create(id: "730315721", first_name: 'บุริศร์', last_name: 'ชลวิรัชกุล', picture: 'pic_url_here', ssn: '10000000071', birth_date:'1-17-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'bytedini@gmail.com', curriculum_id: '4')
Student.create(id: "730271721", first_name: 'ธีรโชติ', last_name: 'บุญประภากร', picture: 'pic_url_here', ssn: '10000000072', birth_date:'12-27-1995', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'Minorisorest@gmail.com', curriculum_id: '5')
Student.create(id: "730679121", first_name: 'อรรถพร', last_name: 'พินิจนารถ', picture: 'pic_url_here', ssn: '10000000073', birth_date:'10-3-1995', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'qwertygms@hotmail.com', curriculum_id: '5')
Student.create(id: "730325021", first_name: 'ปพน', last_name: 'ตรงประกอบ', picture: 'pic_url_here', ssn: '10000000074', birth_date:'12-26-1994', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'frisky.pop@hotmail.com', curriculum_id: '5')
Student.create(id: "730541121", first_name: 'วศิน', last_name: 'วัฒนศรีส่ง', picture: 'pic_url_here', ssn: '10000000075', birth_date:'1-6-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'tep_pan35@hotmail.com', curriculum_id: '5')
Student.create(id: "730108121", first_name: 'ชนาธิป', last_name: 'แซ่เตีย', picture: 'pic_url_here', ssn: '10000000076', birth_date:'11-5-1995', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'chanatippung@hotmail.com', curriculum_id: '5')
Student.create(id: "731001821", first_name: 'กนกพล', last_name: 'ธงไชยเจริญสิริ', picture: 'pic_url_here', ssn: '10000000077', birth_date:'11-6-1995', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'p.pppping@hotmail.com', curriculum_id: '5')
Student.create(id: "730399421", first_name: 'พิชญุุตม์', last_name: 'พฤฒิพฤกษ์', picture: 'pic_url_here', ssn: '10000000078', birth_date:'3-13-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'blazing.green.emerald@gmail.com', curriculum_id: '5')
Student.create(id: "731054021", first_name: 'ธารา', last_name: 'ธรรมมานุธรรม', picture: 'pic_url_here', ssn: '10000000079', birth_date:'8-23-1995', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'pouy1942@hotmail.com', curriculum_id: '5')
Student.create(id: "730456521", first_name: 'ภาสกร', last_name: 'เฮงประเสริฐ', picture: 'pic_url_here', ssn: '10000000080', birth_date:'5-31-1995', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'premmii.em@gmail.com', curriculum_id: '5')
Student.create(id: "731005321", first_name: 'กษิดิศ', last_name: 'เอี่ยมทอง', picture: 'pic_url_here', ssn: '10000000081', birth_date:'6-14-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'kasidit@outlook.com', curriculum_id: '5')
Student.create(id: "731058621", first_name: 'ธีรพจน์', last_name: 'แซ่ลิน', picture: 'pic_url_here', ssn: '10000000082', birth_date:'1-4-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'ropcj@hotmail.com', curriculum_id: '5')
Student.create(id: "731062021", first_name: 'นพวิทย์', last_name: 'ไทยรุ่งโรจน์', picture: 'pic_url_here', ssn: '10000000084', birth_date:'6-9-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'pee.mamypoko@gmail.com', curriculum_id: '5')
Student.create(id: "731083221", first_name: 'พีรวุฒิ', last_name: 'เหลืองเรืองโรจน์', picture: 'pic_url_here', ssn: '10000000085', birth_date:'12-21-1995', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'pee.luang45@gmail.com', curriculum_id: '5')
Student.create(id: "731105421", first_name: 'ศุภวิชญ์', last_name: 'คงธนาฤทธิ์', picture: 'pic_url_here', ssn: '10000000086', birth_date:'1-11-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'flukyy_supp@hotmail.com', curriculum_id: '5')
Student.create(id: "731019121", first_name: 'จิรายุ', last_name: 'อริยเดช', picture: 'pic_url_here', ssn: '10000000087', birth_date:'4-6-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'vbssoloww@gmail.com', curriculum_id: '5')
Student.create(id: "730185421", first_name: 'ณัฐวัฒน์', last_name: 'ประดุจเดชา', picture: 'pic_url_here', ssn: '10000000088', birth_date:'2-26-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'zfordn@gmail.com', curriculum_id: '5')
Student.create(id: "731081021", first_name: 'พิทวัส', last_name: 'นักร้อง', picture: 'pic_url_here', ssn: '10000000089', birth_date:'11-21-1995', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'fordpittawas@gmail.com', curriculum_id: '5')
Student.create(id: "730160721", first_name: 'ณัฐชนสรณ์', last_name: 'พรมมา', picture: 'pic_url_here', ssn: '10000000090', birth_date:'7-29-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'Harconsarnan@gmail.com', curriculum_id: '5')
Student.create(id: "731084921", first_name: 'พุฒิพัฒน์', last_name: 'ศรีรัตน์ภิญโญ', picture: 'pic_url_here', ssn: '10000000091', birth_date:'5-25-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 's.puttiphatmd@gmail.com', curriculum_id: '5')
Student.create(id: "731100221", first_name: 'วีรภัทร์', last_name: 'จึงสมเจตไพศาล', picture: 'pic_url_here', ssn: '10000000092', birth_date:'1-25-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'psg-rst@hotmail.com', curriculum_id: '5')
Student.create(id: "731006021", first_name: 'กันตณัฐ', last_name: 'ชูเกียรติ', picture: 'pic_url_here', ssn: '10000000093', birth_date:'1-15-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'poom.kie0412@gmail.com', curriculum_id: '5')
Student.create(id: "731017921", first_name: 'จิรัฏฐ์', last_name: 'โพธิ์โลหะกุล', picture: 'pic_url_here', ssn: '10000000094', birth_date:'3-3-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'mark_sk132@hotmail.com', curriculum_id: '5')
Student.create(id: "731042521", first_name: 'ธนพนธ์', last_name: 'ศิริสมภาค', picture: 'pic_url_here', ssn: '10000000095', birth_date:'10-21-1995', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'tmark_s@hotmail.com', curriculum_id: '5')
Student.create(id: "730106921", first_name: 'ชนาธิป', last_name: 'เกรียงไกรเพชร', picture: 'pic_url_here', ssn: '10000000096', birth_date:'2-9-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'mikaecat@gmail.com', curriculum_id: '5')
Student.create(id: "730279821", first_name: 'ธีรภาพ', last_name: 'อภิปาลกุล', picture: 'pic_url_here', ssn: '10000000097', birth_date:'8-8-1995', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'mixtelecom8@gmail.com', curriculum_id: '5')
Student.create(id: "731050521", first_name: 'ธัชชัย', last_name: 'เจียมศร', picture: 'pic_url_here', ssn: '10000000098', birth_date:'5-14-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'naki_war@windowslive.com', curriculum_id: '5')
Student.create(id: "731113421", first_name: 'อภิรุจ', last_name: 'ชุ่มวัฒนะ', picture: 'pic_url_here', ssn: '10000000099', birth_date:'3-16-1995', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'kubigiri@hotmail.com', curriculum_id: '5')
Student.create(id: "730097921", first_name: 'เจษฎา', last_name: 'ไวส์คาร์เวอร์', picture: 'pic_url_here', ssn: '10000000100', birth_date:'3-24-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'jessada.wise@gmail.com', curriculum_id: '5')
Student.create(id: "730662421", first_name: 'อติพงศ์', last_name: 'โกมารกุล ณ นคร', picture: 'pic_url_here', ssn: '10000000101', birth_date:'8-17-1996', gender: 'Male', enroll_year: '2014', status:'normal', email: 'devil.gnow@gmail.com', curriculum_id: '5')
Student.create(id: "730054921", first_name: 'ขจรพล', last_name: 'อานันทนิตย์', picture: 'pic_url_here', ssn: '10000000102', birth_date:'9-11-1995', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'vomoboros@gmail.com', curriculum_id: '5')
Student.create(id: "730467421", first_name: 'ภูริณัฐ', last_name: 'จันทร์หอม', picture: 'pic_url_here', ssn: '10000000103', birth_date:'4-4-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'cphurinut@hotmail.com', curriculum_id: '5')
Student.create(id: "730653821", first_name: 'สุวพัชร', last_name: 'วรสิทธิ์', picture: 'pic_url_here', ssn: '10000000104', birth_date:'9-7-1995', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'suwapat.wow@gmail.com', curriculum_id: '5')
Student.create(id: "731013321", first_name: 'คณิติน', last_name: 'จันทร์ประเสริฐ', picture: 'pic_url_here', ssn: '10000000105', birth_date:'2-2-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'khanitin@hotmail.com', curriculum_id: '5')
Student.create(id: "730518821", first_name: 'วรรธนัย', last_name: 'บุรีทาน', picture: 'pic_url_here', ssn: '10000000106', birth_date:'4-2-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'snooker49513@hotmail.com', curriculum_id: '5')
Student.create(id: "731037421", first_name: 'ตรัยรัตน์', last_name: 'ปัญญาวัฒนานุกูล', picture: 'pic_url_here', ssn: '10000000107', birth_date:'9-5-1995', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'samoooop@gmail.com', curriculum_id: '5')
Student.create(id: "730337521", first_name: 'ปัญญพล', last_name: 'ชื่นวัฒนกุล', picture: 'pic_url_here', ssn: '10000000108', birth_date:'8-1-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'singto_victor@hotmail.com', curriculum_id: '5')
Student.create(id: "731012721", first_name: 'โกเศส', last_name: 'ลิ้มพงษา', picture: 'pic_url_here', ssn: '10000000109', birth_date:'8-18-1995', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'kosatelim@hotmail.com', curriculum_id: '5')
Student.create(id: "731034521", first_name: 'ณัฐภัท', last_name: 'ธานินธรณ์', picture: 'pic_url_here', ssn: '10000000110', birth_date:'6-30-1995', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'mugen_rebellion@outlook.com', curriculum_id: '5')
Student.create(id: "730539021", first_name: 'วศิน', last_name: 'แซ่โง้ว', picture: 'pic_url_here', ssn: '10000000111', birth_date:'1-13-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'liang_wasin@hotmail.co.th', curriculum_id: '5')
Student.create(id: "730626921", first_name: 'สิทธินนท์', last_name: 'มั่นพรรษา', picture: 'pic_url_here', ssn: '10000000112', birth_date:'6-6-1995', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'manpansa_aontiger@hotmail.com', curriculum_id: '5')
Student.create(id: "731033921", first_name: 'ณัฐนันท์', last_name: 'วัชรเกษมสินธุ์', picture: 'pic_url_here', ssn: '10000000113', birth_date:'8-7-1995', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'fifapesrf@gmail.com', curriculum_id: '5')
Student.create(id: "730329521", first_name: 'ปรินทร', last_name: 'ทรายทอง', picture: 'pic_url_here', ssn: '10000000114', birth_date:'8-30-1995', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'pirsquareff@gmail.com', curriculum_id: '5')
Student.create(id: "731104821", first_name: 'ดนุภัทร', last_name: 'รงศ์เหลืองอร่าม', picture: 'pic_url_here', ssn: '10000000115', birth_date:'2-2-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'supanut2feb2539@hotmail.com', curriculum_id: '5')
Student.create(id: "730400321", first_name: 'พิชไนย', last_name: 'ฐิติภากร', picture: 'pic_url_here', ssn: '10000000116', birth_date:'3-31-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'pit_maplestory@hotmail.com', curriculum_id: '5')
Student.create(id: "731114021", first_name: 'อัมรินทร์', last_name: 'เจตน์ฐากูร', picture: 'pic_url_here', ssn: '10000000117', birth_date:'12-9-1995', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'ammarinjtk@outlook.com', curriculum_id: '5')
Student.create(id: "731025921", first_name: 'ชัยภัทร', last_name: 'จุลศรี', picture: 'pic_url_here', ssn: '10000000118', birth_date:'12-24-1995', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'adelaide.8000@gmail.com', curriculum_id: '5')
Student.create(id: "730059021", first_name: 'คณิน', last_name: 'ศุภสัจญาณกุล', picture: 'pic_url_here', ssn: '10000000119', birth_date:'9-20-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'oak_maplestory@hotmail.com', curriculum_id: '5')
Student.create(id: "731008221", first_name: 'กิติพงษ์', last_name: 'ศิริเรืองสกุล', picture: 'pic_url_here', ssn: '10000000120', birth_date:'2-2-1996', gender: 'Male', enroll_year: '2014', status: 'Dropped', email: 'kittipong1996@hotmail.com', curriculum_id: '5')
Student.create(id: "731071721", first_name: 'ปธานิน', last_name: 'โลกโบว์', picture: 'pic_url_here', ssn: '10000000121', birth_date:'3-16-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'oatoat555@gmail.com', curriculum_id: '5')
Student.create(id: "730657321", first_name: 'เสฏฐวุฒิ', last_name: 'อดิศัยสกุลเดช', picture: 'pic_url_here', ssn: '10000000122', birth_date:'10-17-1996', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'settavut_ham@outlook.com', curriculum_id: '5')
Student.create(id: "731067221", first_name: 'นิธิรันดร์', last_name: 'นุ่มนนท์', picture: 'pic_url_here', ssn: '10000000123', birth_date:'8-16-1995', gender: 'Male', enroll_year: '2014', status: 'normal', email: 'nithirun1995@gmail.com', curriculum_id: '5')##

#Didn't handle duplication of data

#Personnel_create
for i in 0..25
  personnel = Personnel.create(id: '12' + i.to_s, email: 'test' + i.to_s + '@cu.com' , role: 'I', password: 'dbdbdbdb')
  #puts personnel.errors.messages
end

#Advisor_create
for i in 0..50
	Advisor.create(student_id: Student.offset(rand(Student.count)).first.id,
					personnel_id: Personnel.offset(rand(Personnel.count)).first.id)
end

#Group_create
for i in 0..50
	Group.create(name: "Sai rung pung ta yan",
				id: i)
end

#Belong_to_create
for i in 0..200
	BelongTo.create(student_id: Student.offset(rand(Student.count)).first.id,
					group_id: Group.offset(rand(Group.count)).first.id,
					id: i)
end

#Portfolio_create
for i in 0..50
	Portfolio.create(date: rand(Date.civil(1990, 1, 1)..Date.civil(2050, 12, 31)),
					explanation: "Do something good!!",
					name: "Name of portfolio is here",
					group_id: rand(50), # Random by group
					id: i)
end

#Activity_create: ISA of Portfolio
activity_position = ["Labor", "Leader", "Thinker", "Eater"]
for i in 0..25
	Activity.create(position: activity_position[rand(4)], 
					duration: rand(10), 
					portfolio_id: i)
end

#Competition_create: ISA of Portfolio
for i in 26..50
	Competition.create(award: ("#{rand(10)}st Place in the entire universe."),
						portfolio_id: i)
end

#Leave_create
for i in 0..50
	date1 = rand(Date.civil(1990, 1, 1)..Date.civil(2050, 12, 31))
	date2 = rand(Date.civil(1990, 1, 1)..Date.civil(2050, 12, 31))
	if date1 > date2
		date_temp = date1
		date1 = date2
		date2 = date_temp
	end
	Leave.create(start_date: date1,
				end_date: date2,
				group_id: rand(Group.count),
				id: i)
end

#Personal_leave_create: ISA of Leave
for i in 0..25
	PersonalLeave.create(project_name: "Untitled-#{rand(10)}",
						leave_id: i)
end

#Sick_leave_create: ISA of Leave
for i in 26..50
	SickLeave.create(reason: "Flu Number#{rand(10)}",
					leave_id: i)
end

#Rule_create
for i in 0..20
	Rule.create(rule_detail: "Sell drug(s) #{rand(50)}kg. of drugs",
				behavior_score_reduction: rand(5)*5,
				id: i)
end

#Log_break_create
for i in 0..50
	LogBreak.create(remark: "Level of Severity = #{rand(5)}",
					when: rand(Date.civil(1990, 1, 1)..Date.civil(2050, 12, 31)),
					rule_id: rand(Rule.count),
					student_id: Student.offset(rand(Student.count)).first.id,
					id: i)
end

#Department_create
for i in 0..10
	Department.create(name: "Department Name number #{i}",
						id: i)
end

#Course_Category_create
Cat = ["GEN ED", "BUNG KUB", "GEN LANG"]
for i in 0..20
	Code.create(id: "#{i+200}0000",
						department_id: rand(Department.count),
						category: Cat[rand(3)])
end

#Course_create
for i in 0..10
	Course.create(name: "Introduction to life Part #{i}",
				code_id: rand(Code.count),
				credit: rand(3)+1,
				id: i)
end

#Section_create
for i in 0..50
	Section.create(sec: rand(3),
					year: rand(5)+2012,
					semester: rand(3),
					course_id: rand(Course.count),
					personnel_id: Personnel.offset(rand(Personnel.count)).first.id,
					id: i)
end

#Time_slot_create
for i in 0..50
	TimeSlot.create(day: "#{rand(7)+1}th day of the week",
					start: Time.now,
					end: Time.now + 60*60,
					id: i)
end

#Schedule_create
for i in 0..50
	Schedule.create(section_id: i,
					time_slot_id: i)
end

#Enrollment_create
for i in 0..20
	Enrollment.create(grade: rand(8), # A = 8, F = 0
					section_id: rand(Section.count),
					student_id: Student.offset(rand(Student.count)).first.id)
end

#Curriculum_create
for i in 0..15
	Curriculum.create(name: "CUR NAME No.#{i}",
					description: "Description No.#{i}",
					department_id: rand(Department.count),
					id: i)
end

#Require_create
for i in 0..(Curriculum.count-1)
	for j in 0..rand(4)
		Require.create(curriculum_id: i,
						course_id: rand(Course.count))
	end
end

#GPA_create
for i in 0..(Student.count-1)
	for j in 2014..2017
		for k in 1..3
			Gpa.create(year: j,
						semester: k,
						credit: rand(5)+16,
						gpa: rand(200)+100,
						student_id: Student.offset(i).first.id)
		end
	end
end

